<?php
    if (PHP_SAPI !== 'cli' && php_sapi_name() !== 'cli' && !defined('STDIN')) {
        if (!headers_sent()) {
            header('Content-Type: text/plain; charset=utf-8', true, 403);
        }
        echo "Forbidden: script, only alowd by command line (CLI).\n";
        exit(1);
    }
    define("EdoCMS",True);
    require_once "opt/mainconfig.php";
    $serverIP   = '127.0.0.1';

    $sql = "SELECT * FROM `server` where serverip='$serverIP' order by `id` asc ";
    $result = mysql_query($sql);
    $rows = mysql_num_rows($result);
    if ($rows){
        while($row = mysql_fetch_array($result)){
            $servername         = $row['servername'];
            $storagepath        = $row['storagepath'];
            $id                 = $row['id'];
            $subdomain          = $row['subdomain'];
            $user               = $row['user'];
            $size               = getFolderSize($storagepath);
            $resultCert         = getSSLCertExpiry($subdomain);
            $RawMem             = getServerMemoryUsage();
            $memPercent         = $RawMem['used_percent'];
            if($user){
                $cpu                = getServerCpuUsage(1,$user);
            } else {
                $cpu                = getServerCpuUsage(1);
            }
            if(is_array($resultCert)){
                $expireSSL = $resultCert['expiry_date'];
                $issuer = addslashes($resultCert['issuer']);
                echo "Expire SSL : {$resultCert['expiry_date']}\n\n";
                $sqlInsert  = "UPDATE `server` SET `cpu`='$cpu',`memory`='$memPercent',`storage`='$size', `ssl` = '$expireSSL',`issuer`='$issuer',`lastcheck`=now() WHERE `id` = $id ;";
                mysql_query($sqlInsert);
            } else {
                $sqlInsert  = "UPDATE `server` SET `cpu`='$cpu', `memory`='$memPercent',`storage`='$size', `issuer`='N/A',`lastcheck`=now() WHERE `id` = $id ;";
                mysql_query($sqlInsert);  
            }
            usleep(500000);
        }
    }