<?php
    if (!defined('EdoCMS')) { header("location:?"); die; }
    date_default_timezone_set("Asia/Jakarta");
    $Config['Mysql_Server']                 = 'localhost';
    $Config['Mysql_Password']               = '';
    $Config['Mysql_DB']                     = 'edocms';
    $Config['Mysql_User']                   = 'root';
    $Config['UploadDir']                    = "/var/www/html/uploads/";
    $imgUploadExtension                     = array("image/gif","image/png","image/jpg","image/bmp","image/jpeg");

    //-----------------------------Do Not Edit This line if you dont know what it is---------------------------------------------------------------
    if (function_exists('mysql_connect')) {
            $DbConn = mysql_connect($Config['Mysql_Server'],$Config['Mysql_User'],$Config['Mysql_Password']) OR DIE('<center>Error Cant Connect To Server</center>');
            @mysql_select_db($Config['Mysql_DB']) OR DIE ('<center>Error Cant Connect To Database</center>');
            $ErrorSql = mysql_error($DbConn);
    }else{
            $DbConn = @mysqli_connect($Config['Mysql_Server'],$Config['Mysql_User'],$Config['Mysql_Password'],$Config['Mysql_DB']) OR DIE('<center>Error Cant Connect To Local Server</center>');
            function mysql_query($OldQuery){global $DbConn;$hasil =  mysqli_query($DbConn,$OldQuery);return $hasil;}
            function mysql_multi_query($OldQuery){global $DbConn;$hasil =  mysqli_multi_query($DbConn,$OldQuery);do{}while (mysqli_next_result($DbConn));return $hasil;}
            function mysql_num_rows($Oldnum_rows){$hasil = mysqli_num_rows($Oldnum_rows);return $hasil;}
            function mysql_fetch_array($Oldfetch_array){$hasil = mysqli_fetch_array($Oldfetch_array);return $hasil;}
            $ErrorSql = $DbConn -> connect_error;
    }
    function rupiah($nominal) {
        $panjang =strlen($nominal) ;
        $lop=0;
        $fo="";
        for ($i=$panjang;$i>0;$i--){
            $lop++ ;
            if ($lop==4){
                $lop=1;
                $sb="." ;
            } else {
                $sb="" ;
            }
        $hit = substr($nominal,$i-1,1) ;
        $fo = "#$hit$sb$fo";
    }
    $fo = str_replace('#.0','0',$fo ) ;
    $fo = str_replace('#.1','1',$fo ) ;
    $fo = str_replace('#.2','2',$fo ) ;
    $fo = str_replace('#.3','3',$fo ) ;
    $fo = str_replace('#.4','4',$fo ) ;
    $fo = str_replace('#.5','5',$fo ) ;
    $fo = str_replace('#.6','6',$fo ) ;
    $fo = str_replace('#.7','7',$fo ) ;
    $fo = str_replace('#.8','8',$fo ) ;
    $fo = str_replace('#.9','9',$fo ) ;
    $fo = str_replace('#','',$fo ) ;
    return "$fo";
}

function CheckModuleGroupExist($gid,$uid){
    $FuncSql = "SELECT module.id FROM `module` left join userakses on (userakses.idmodule=module.id) where `idmodulegroup`=$gid and userakses.iduser=$uid and userakses.akses >=1 order by module.id asc limit 0,1";
    $Funcresult = mysql_query($FuncSql);
    $Funcrows = mysql_num_rows($Funcresult);
    if ($Funcrows){
        return true;
    } else {
        return false;
    }
}
function GetGroupIdByModId($gid){
    $FuncSql = "SELECT id FROM `module` where `idmodulegroup`=$gid LIMIT 0,1";
    $Funcresult = mysql_query($FuncSql);
    $Funcrows = mysql_num_rows($Funcresult);
    if ($Funcrows){
        while($Funcrow = mysql_fetch_array($Funcresult)){
            $gid = $Funcrow['id'];
        }
        return $gid;
    } else {
        return false;
    }
}
function getSSLCertExpiry($domain, $port = 443) {
    $streamContext = stream_context_create([
        "ssl" => [
            "capture_peer_cert" => true,
            "verify_peer" => false,
            "verify_peer_name" => false,
        ],
    ]);

    $client = @stream_socket_client(
        "ssl://{$domain}:{$port}",
        $errno,
        $errstr,
        30,
        STREAM_CLIENT_CONNECT,
        $streamContext
    );

    if (!$client) {
        return "Gagal konek ke $domain:$port - $errstr";
    }

    $params = stream_context_get_params($client);
    $cert   = $params['options']['ssl']['peer_certificate'];

    // Ambil informasi cert
    $certInfo = openssl_x509_parse($cert);

    if (!$certInfo) {
        return "Tidak bisa parse certificate";
    }

    $validTo    = $certInfo['validTo_time_t'];
    $expiryDate = date("Y-m-d", $validTo); // format YYYY-MM-DD
    $daysLeft   = floor(($validTo - time()) / 86400);

    // Ambil issuer (penerbit SSL)
    $issuer = $certInfo['issuer'];
    $issuerName = $issuer['O'] ?? ($issuer['CN'] ?? 'Unknown');

    return [
        "domain"       => $domain,
        "expiry_date"  => $expiryDate,
        "days_left"    => $daysLeft,
        "issuer"       => $issuerName
    ];
}

function whoisQuery($domain, $whoisServer) {
    $fp = @fsockopen($whoisServer, 43);
    if (!$fp) {
        return false;
    }

    fwrite($fp, $domain . "\r\n");
    $response = "";
    while (!feof($fp)) {
        $response .= fgets($fp, 128);
    }
    fclose($fp);
    return $response;
}

function getWhoisServer($domain) {
    $tld = strtolower(pathinfo($domain, PATHINFO_EXTENSION));
    $servers = [
        "com" => "whois.verisign-grs.com",
        "net" => "whois.verisign-grs.net",
        "org" => "whois.pir.org",
        "id"  => "whois.id",
        "xyz" => "whois.nic.xyz",
        "info"=> "whois.afilias.net",
        "co"   => "whois.nic.co", 
    ];
    return $servers[$tld] ?? null;
}

function getDomainExpiry($domain) {
    $whoisServer = getWhoisServer($domain);
    if (!$whoisServer) {
        return "TLD tidak dikenali atau belum ada WHOIS server yang didefinisikan.";
    }

    $result = whoisQuery($domain, $whoisServer);
    if (!$result) {
        return "Tidak bisa mengambil data WHOIS dari $whoisServer";
    }

    if (preg_match('/Expir(?:y|ation) Date:\s?(.+)/i', $result, $matches)) {
        $expiryRaw = trim($matches[1]);
        $expiryDate = date("Y-m-d", strtotime($expiryRaw));
        $daysLeft = floor((strtotime($expiryDate) - time()) / 86400);
        return [
            "domain" => $domain,
            "expiry_date" => $expiryDate,
            "days_left" => $daysLeft
        ];
    }

    return "Tidak bisa menemukan tanggal expired pada $domain data dari $whoisServer\n $result";
}

function getBaseDomain($domain) {
    $domain = strtolower(trim($domain));
    $parts  = explode('.', $domain);

    // Kalau hanya ada 2 bagian (example.com / domain.id) -> return langsung
    if (count($parts) <= 2) {
        return $domain;
    }

    // Daftar TLD 2-level Indonesia
    $specialTLDs = [
        'co.id', 'ac.id', 'or.id', 'web.id', 'sch.id', 'my.id', 'biz.id'
    ];

    $last2 = implode('.', array_slice($parts, -2)); // contoh.com / domain.id
    $last3 = implode('.', array_slice($parts, -3)); // contoh.co.id

    // Jika TLD 2-level Indonesia (contoh.co.id, kampus.ac.id, dll.)
    foreach ($specialTLDs as $tld) {
        if (substr($last3, -strlen($tld)) === $tld) {
            return $last3;
        }
    }

    // Default: gunakan 2 bagian terakhir (contoh.com, domain.id)
    return $last2;
}

function CheckUserAkses($uid,$modid){
    $FuncSql="SELECT akses FROM `userakses` where iduser='$uid' and `idmodule`='$modid'; ";
    $Funcresult = mysql_query($FuncSql);
    $Funcrows = mysql_num_rows($Funcresult);
    if ($Funcrows){
        while($Funcrow = mysql_fetch_array($Funcresult)){
            $gid = $Funcrow['akses'];
        }
        return $gid;
    } else {
        return false;
    }
}
function getModuleInfo($modid){
    $FuncSql="SELECT module.id,module.title,module.icon,module.path,modulegroup.title as groupName, module.icon as groupIcon FROM `module` left join modulegroup on (modulegroup.id=module.idmodulegroup) where module.id='$modid'; ";
    $Funcresult = mysql_query($FuncSql);
    $Funcrows = mysql_num_rows($Funcresult);
    if ($Funcrows){
        while($Funcrow = mysql_fetch_array($Funcresult)){
            $path = $Funcrow['path'];
            $icon = $Funcrow['icon'];
            $title = $Funcrow['title'];
            $groupName = $Funcrow['groupName'];
            $groupIcon = $Funcrow['groupIcon'];

        }
    return [
        "path"       => $path,
        "icon"  => $icon,
        "title"    => $title,
        "id"       => $modid,
        "groupName"       => $groupName,
        "groupIcon"       => $groupIcon
    ];
    } else {
        return false;
    }
}

function getDaysLeft($targetDate) {
    $today  = new DateTime();               // waktu sekarang
    $target = new DateTime($targetDate);    // tanggal target

    $diff = $today->diff($target);
    $daysLeft = (int)$diff->format("%r%a"); // bisa negatif kalau sudah lewat

    return $daysLeft;
}

function getFolderSize($dir) {
    $size = 0;

    if (!is_dir($dir)) {
        return 0;
    }

    $files = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS)
    );

    foreach ($files as $file) {
        $size += $file->getSize();
    }

    return formatSize($size);
}

function formatSize($bytes) {
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $i = 0;
    while ($bytes >= 1024 && $i < count($units) - 1) {
        $bytes /= 1024;
        $i++;
    }
    return round($bytes, 2) . ' ' . $units[$i];
}

function getServerMemoryUsage($username = null, $processName = null) {
    $os = PHP_OS_FAMILY;

    if ($os === "Linux") {
        if ($processName !== null) {
            // Memory per process tertentu
            $cmd = sprintf("ps -C %s -o rss= 2>/dev/null", escapeshellarg($processName));
        } elseif ($username !== null) {
            // Memory per user
            $cmd = sprintf("ps -U %s -o rss= 2>/dev/null", escapeshellarg($username));
        } else {
            // Total memory server
            if (!is_readable("/proc/meminfo")) return null;
            $data = file_get_contents("/proc/meminfo");
            preg_match('/MemTotal:\s+(\d+)/', $data, $m1);
            preg_match('/MemAvailable:\s+(\d+)/', $data, $m2);
            if (!$m1 || !$m2) return null;

            $total = (int)$m1[1];       // KB
            $available = (int)$m2[1];   // KB
            $used = $total - $available;
            return [
                "total_kb" => $total,
                "used_kb" => $used,
                "free_kb" => $available,
                "used_percent" => round(($used/$total)*100, 2),
            ];
        }

        @exec($cmd, $output);
        $sumKb = 0;
        foreach ($output as $line) {
            $sumKb += (int)trim($line);
        }

        return [
            "target" => $username ?? $processName,
            "memory_kb" => $sumKb,
            "memory_human" => formatBytes($sumKb * 1024)
        ];

    } elseif ($os === "Windows") {
        if ($processName !== null) {
            $filter = 'IMAGENAME eq ' . $processName;
        } elseif ($username !== null) {
            $filter = 'USERNAME eq ' . $username;
        } else {
            // total memory server via wmic
            @exec("wmic OS get FreePhysicalMemory,TotalVisibleMemorySize /Value", $output);
            $free = $total = 0;
            foreach ($output as $line) {
                if (stripos($line, "FreePhysicalMemory") !== false) {
                    $free = (int) filter_var($line, FILTER_SANITIZE_NUMBER_INT);
                } elseif (stripos($line, "TotalVisibleMemorySize") !== false) {
                    $total = (int) filter_var($line, FILTER_SANITIZE_NUMBER_INT);
                }
            }
            $used = $total - $free;
            return [
                "total_kb" => $total,
                "used_kb" => $used,
                "free_kb" => $free,
                "used_percent" => round(($used/$total)*100,2),
            ];
        }

        // tasklist filter
        $cmd = 'tasklist /FI "' . $filter . '" /FO CSV /NH';
        @exec($cmd, $lines);
        $sumKb = 0;
        foreach ($lines as $line) {
            $cols = str_getcsv($line);
            if (count($cols) < 5) continue;
            $memStr = $cols[4]; // contoh "12,345 K"
            $memKb = (int) str_replace([",","K"], "", $memStr);
            $sumKb += $memKb;
        }

        return [
            "target" => $username ?? $processName,
            "memory_kb" => $sumKb,
            "memory_human" => formatBytes($sumKb * 1024)
        ];
    }

    return null;
}

function formatBytes($bytes, $precision = 2) {
    $units = ['B','KB','MB','GB','TB'];
    $i = 0;
    while ($bytes >= 1024 && $i < count($units)-1) {
        $bytes /= 1024;
        $i++;
    }
    return round($bytes,$precision).' '.$units[$i];
}


function getServerCpuUsage($interval = 1, $username = null) {
    $os = PHP_OS_FAMILY;

    if ($os === "Linux") {
        if ($username === null) {
            // Mode total CPU (pakai /proc/stat)
            $stat1 = getLinuxCpuStat();
            if (!$stat1) return null;
            sleep($interval);
            $stat2 = getLinuxCpuStat();
            if (!$stat2) return null;

            $total1 = array_sum($stat1);
            $total2 = array_sum($stat2);

            $idle1 = $stat1['idle'] + $stat1['iowait'];
            $idle2 = $stat2['idle'] + $stat2['iowait'];

            $totalDiff = $total2 - $total1;
            $idleDiff  = $idle2 - $idle1;

            if ($totalDiff == 0) return null;

            $usage = (1 - ($idleDiff / $totalDiff)) * 100;
            return round($usage, 2);
        } else {
            // Mode per user (pakai ps)
            $cmd = sprintf("ps -U %s -o %%cpu --no-headers", escapeshellarg($username));
            @exec($cmd, $output);

            $sum = 0;
            foreach ($output as $line) {
                $sum += (float)trim($line);
            }
            return round($sum, 2);
        }
    } elseif ($os === "Windows") {
        if ($username === null) {
            @exec("wmic cpu get loadpercentage /value", $output);
            foreach ($output as $line) {
                if (stripos($line, "LoadPercentage") !== false) {
                    return (float) filter_var($line, FILTER_SANITIZE_NUMBER_INT);
                }
            }
        } else {
            // Windows per-user CPU agak ribet → butuh PowerShell
            $cmd = 'powershell -Command "Get-Process | Where-Object { $_.StartInfo.UserName -like \'' . $username . '*\' } | Measure-Object CPU -Sum | Select -ExpandProperty Sum"';
            @exec($cmd, $output);
            if (!empty($output[0])) {
                return (float)$output[0]; // Note: ini CPU time, bukan persentase langsung
            }
        }
    }

    return null;
}

/**
 * Ambil statistik CPU dari /proc/stat (Linux)
 * @return array|null
 */
function getLinuxCpuStat() {
    if (!is_readable("/proc/stat")) return null;
    $line = fgets(fopen("/proc/stat", "r"));
    if (!preg_match('/^cpu\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)/', $line, $m)) {
        return null;
    }

    return [
        "user" => (int)$m[1],
        "nice" => (int)$m[2],
        "system" => (int)$m[3],
        "idle" => (int)$m[4],
        "iowait" => (int)$m[5],
        "irq" => (int)$m[6],
        "softirq" => (int)$m[7],
    ];
}
