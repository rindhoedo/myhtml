<?php
	if (!defined('EdoCMS')) { header("location:?"); die; }
?>
<nav>
	<ul>
	<?php
		$sql = "SELECT * FROM `modulegroup` order by `position` asc";
        $result = mysql_query($sql);
		$rows = mysql_num_rows($result);
		if ($rows){
			while($row = mysql_fetch_array($result)){
				$idGroup       = $row["id"];
				if(CheckModuleGroupExist($idGroup,$id_pengguna)){
					$Title		= $row['title'];
					$Icon		= $row['icon'];
					if($CurrGroup=="$idGroup"){
						echo '<li class="open">';
					}else{
						echo '<li class="">';
					}
					echo '<a href="#" title="Dashboard"><i class="fa fa-fw '.$Icon.'"></i> <span class="menu-item-parent">'.$Title.'</span></a>';
					
					$ModSql = "SELECT module.id,module.icon,module.title FROM `module` left join userakses on (userakses.idmodule=module.id) where `idmodulegroup`='$idGroup' and iduser=$id_pengguna and akses>=1 order by `position` asc";
					$ModResult = mysql_query($ModSql);
					$ModRows = mysql_num_rows($ModResult);
					if ($ModRows){
						echo '<ul>';
						while($ModRow = mysql_fetch_array($ModResult)){
							$ModTitle		= $ModRow['title'];
							$ModIcon		= $ModRow['icon'];
							$ModId			= $ModRow['id'];
							if($ModId=="$CurrMod"){
								$modStat='active';
							}else{
								$modStat='';
							}

							echo '<li class="'.$modStat.'" ><a href="?module='.$ModId.'"><i class="fa fa-fw '.$ModIcon.'"></i> '.$ModTitle.'</a></li>';
						}
						echo '</ul>';
					}
					echo '</li>';
				}
			}
		}
	?>
	</ul>
</nav>
