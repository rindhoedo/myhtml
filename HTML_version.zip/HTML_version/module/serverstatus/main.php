<?php
	if (!defined('EdoCMS')) { header("location:?"); die; }
?>
<div class="row">
    <table class="table table-hover">
        <thead>
            <tr>
                <th>#</th>
                <th>Server Name</th>
                <th>SSL Expire</th>
                <th>SSL Issuer</th>
                <th>Respone Time</th>
                <th>Storage</th>
                <th>Mem Info</th>
                <th>Cpu Info</th>
                <th>Last Check</th>

            </tr>
        </thead>
        <tbody>
            <?php 
            $sql = "SELECT * FROM `server` order by id asc";
            $result = mysql_query($sql);
            $rows = mysql_num_rows($result);
            if ($rows){
                $x=1;
                while($row = mysql_fetch_array($result)){


                        echo '<tr>';
                        echo '    <td>'.$x.'</td>';
                        echo '    <td>'.$row['subdomain'].'</td>';
                        echo '    <td>'.$row['ssl'].'</td>';
                        echo '    <td>'.$row['issuer'].'</td>';
                        echo '    <td>'.$row['responsetime'].' MS</td>';
                        echo '    <td>'.$row['storage'].'</td>';
                        echo '    <td>'.$row['memory'].' %</td>';
                        echo '    <td>'.$row['cpu'].' %</td>';
                        echo '    <td>'.$row['lastcheck'].'</td>';
                        echo '</tr>';
                        $x++;
   
                }
            }
            ?>
        </tbody>
    </table>
</div>