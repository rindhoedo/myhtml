<?php
	if (!defined('EdoCMS')) { header("location:?"); die; }
?>
<div class="row">
    <table class="table table-hover">
        <thead>
            <tr>
                <th>#</th>
                <th>Domain</th>
                <th>Domain Expire</th>
                <th>Days left</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $sql = "SELECT * FROM `tbldomain` order by id asc";
            $result = mysql_query($sql);
            $rows = mysql_num_rows($result);
            if ($rows){
                $x=1;
                while($row = mysql_fetch_array($result)){
                    $setDomain  = $row['domain'];
                    $fqdnDomain = getBaseDomain($row['domain']);
                    if($setDomain=="$fqdnDomain"){
                        $daysLeft = getDaysLeft($row['expire']);
                        echo '<tr>';
                        echo '    <td>'.$x.'</td>';
                        echo '    <td>'.$row['domain'].'</td>';
                        echo '    <td>'.$row['expire'].'</td>';
                        echo '    <td>'.$daysLeft.'</td>';
                        echo '</tr>';
                        $x++;
                    }
                }
            }
            ?>
        </tbody>
    </table>
</div>