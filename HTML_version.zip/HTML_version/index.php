<?php
    session_start();
    //if (isset($_SESSION['AppStatus']) and $_SESSION['AppStatus']==True){
            $id_pengguna                    = '1'; //$_SESSION['id_pengguna'];
            $email_pengguna                 = 'rindhoedo@gmail.com' ; //$_SESSION['email_pengguna'];
            $nama_pengguna                  = 'Rindho Tias Perwira'; //$_SESSION['nama_pengguna'];
    //}
    define("EdoCMS",True);
    include "opt/mainconfig.php";
	$CurrMod                                    = (isset($_GET['module'])?$_GET['module']:1);
    $statusModuleUser   = CheckUserAkses($id_pengguna,$CurrMod);
    if(!$statusModuleUser){
        $CurrMod   =1;
    }
    $ModuleData         = getModuleInfo($CurrMod);
	$CurrGroup									= 1;
	if($CurrMod){
		$CurrGroup								= GetGroupIdByModId($CurrMod);
	}
?>
<!DOCTYPE html>
<html lang="en-us">
	<head>
		<meta charset="utf-8">
		<!--<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">-->

		<title> SmartAdmin </title>
		<meta name="description" content="">
		<meta name="author" content="">
			
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
		<style>
			:root {
				--header-height: 100px;
			}
		</style>
		<!-- Basic Styles -->
		<link rel="stylesheet" type="text/css" media="screen" href="css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" media="screen" href="css/font-awesome.min.css">

		<!-- SmartAdmin Styles : Caution! DO NOT change the order -->
		<link rel="stylesheet" type="text/css" media="screen" href="css/smartadmin-production-plugins.min.css">
		<link rel="stylesheet" type="text/css" media="screen" href="css/smartadmin-production.min.css?x=<?php echo date("Y-m-d H:i:s"); ?>">
		<link rel="stylesheet" type="text/css" media="screen" href="css/smartadmin-skins.min.css?x=<?php echo date("Y-m-d H:i:s"); ?>">

		<!-- SmartAdmin RTL Support  -->
		<link rel="stylesheet" type="text/css" media="screen" href="css/smartadmin-rtl.min.css?x=<?php echo date("Y-m-d H:i:s"); ?>">

		<!-- We recommend you use "your_style.css" to override SmartAdmin
		     specific styles this will also ensure you retrain your customization with each SmartAdmin update.
		<link rel="stylesheet" type="text/css" media="screen" href="css/your_style.css"> -->

		<link rel="stylesheet" type="text/css" media="screen" href="css/your_style.css">
		<!-- FAVICONS -->
		<link rel="shortcut icon" href="img/favicon/favicon.ico" type="image/x-icon">
		<link rel="icon" href="img/favicon/favicon.ico" type="image/x-icon">

		<!-- GOOGLE FONT -->
		<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,700italic,300,400,700">

		<!-- Specifying a Webpage Icon for Web Clip 
			 Ref: https://developer.apple.com/library/ios/documentation/AppleApplications/Reference/SafariWebContent/ConfiguringWebApplications/ConfiguringWebApplications.html -->
		<link rel="apple-touch-icon" href="img/splash/sptouch-icon-iphone.png">
		<link rel="apple-touch-icon" sizes="76x76" href="img/splash/touch-icon-ipad.png">
		<link rel="apple-touch-icon" sizes="120x120" href="img/splash/touch-icon-iphone-retina.png">
		<link rel="apple-touch-icon" sizes="152x152" href="img/splash/touch-icon-ipad-retina.png">
		
		<!-- iOS web-app metas : hides Safari UI Components and Changes Status Bar Appearance -->
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		
		<!-- Startup image for web apps -->
		<link rel="apple-touch-startup-image" href="img/splash/ipad-landscape.png" media="screen and (min-device-width: 481px) and (max-device-width: 1024px) and (orientation:landscape)">
		<link rel="apple-touch-startup-image" href="img/splash/ipad-portrait.png" media="screen and (min-device-width: 481px) and (max-device-width: 1024px) and (orientation:portrait)">
		<link rel="apple-touch-startup-image" href="img/splash/iphone.png" media="screen and (max-device-width: 320px)">
        <script src="https://kit.fontawesome.com/5c36523dea.js" crossorigin="anonymous"></script>
	</head>
	<body class="desktop-detected pace-done fixed-header smart-style-2">
		<header id="header">
			<div id="logo-group">
				<span id="logo"> <img src="img/logo.png" alt="SmartAdmin"> </span>
			</div>
			<div class="pull-right">

				<div id="logout" class="btn-header transparent pull-right">
					<span> <a href="/logout.php" title="Sign Out" ><i class="fa fa-sign-out"></i></a> </span>
				</div>
				<div id="Messages" class="btn-header transparent pull-right">
					<span> <a href="?module=messages" title="Messages" ><i class="fa fa-envelope"></i><em>3</em></a> </span>
				</div>
				<div id="fullscreen" class="btn-header transparent pull-right">
					<span> <a href="javascript:void(0);" data-action="launchFullscreen" title="Full Screen"><i class="fa fa-arrows-alt"></i></a> </span>
				</div>
			</div>
		</header>

		<aside id="left-panel">
			<?php require_once "opt/navigator.php" ?>
		</aside>
		<div id="main" role="main">
			<div id="ribbon">
				<span class="ribbon-button-alignment"> 
					<span id="aaa" class="btn btn-ribbon"  rel="tooltip" >
						<i class="fa fa-refresh"></i>
					</span> 
				</span>
				<ol class="breadcrumb">
                    <li><?php echo $ModuleData['groupName']; ?></li>
                    <li><?php echo $ModuleData['title']; ?></li>
				</ol>
			</div>

			<div id="content">
				<?php 
                    
                    if($statusModuleUser){
                        $filename = "module/".$ModuleData['path']."/main.php"; 
                        if (file_exists($filename)) {
                            require_once "module/".$ModuleData['path']."/main.php";
                        } else {
                            require_once "404.php";
                        }
                    }else{
                        echo "You are not alowed to access this module";
                    }


                ?>
			</div>
		</div>
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
		<script>
			if (!window.jQuery) {
				document.write('<script src="js/libs/jquery-2.1.1.min.js"><\/script>');
			}
		</script>

		<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
		<script>
			if (!window.jQuery.ui) {
				document.write('<script src="js/libs/jquery-ui-1.10.3.min.js"><\/script>');
			}
		</script>

		<!-- IMPORTANT: APP CONFIG -->
		<script src="js/app.config.js"></script>

		<!-- JS TOUCH : include this plugin for mobile drag / drop touch events-->
		<script src="js/plugin/jquery-touch/jquery.ui.touch-punch.min.js"></script> 

		<!-- BOOTSTRAP JS -->
		<script src="js/bootstrap/bootstrap.min.js"></script>

		<!-- CUSTOM NOTIFICATION -->
		<script src="js/notification/SmartNotification.min.js"></script>

		<!-- JARVIS WIDGETS -->
		<script src="js/smartwidgets/jarvis.widget.min.js"></script>

		<!-- EASY PIE CHARTS -->
		<script src="js/plugin/easy-pie-chart/jquery.easy-pie-chart.min.js"></script>

		<!-- SPARKLINES -->
		<script src="js/plugin/sparkline/jquery.sparkline.min.js"></script>

		<!-- JQUERY VALIDATE -->
		<script src="js/plugin/jquery-validate/jquery.validate.min.js"></script>

		<!-- JQUERY MASKED INPUT -->
		<script src="js/plugin/masked-input/jquery.maskedinput.min.js"></script>

		<!-- JQUERY SELECT2 INPUT -->
		<script src="js/plugin/select2/select2.min.js"></script>

		<!-- JQUERY UI + Bootstrap Slider -->
		<script src="js/plugin/bootstrap-slider/bootstrap-slider.min.js"></script>

		<!-- browser msie issue fix -->
		<script src="js/plugin/msie-fix/jquery.mb.browser.min.js"></script>

		<!-- FastClick: For mobile devices -->
		<script src="js/plugin/fastclick/fastclick.min.js"></script>

		<!--[if IE 8]>

		<h1>Your browser is out of date, please update your browser by going to www.microsoft.com/download</h1>

		<![endif]-->

		<!-- Demo purpose only -->



		<script src="js/app.min.js"></script>
		<script src="js/smart-chat-ui/smart.chat.ui.min.js"></script>
		<script src="js/smart-chat-ui/smart.chat.manager.min.js"></script>
		<script src="js/plugin/flot/jquery.flot.cust.min.js"></script>
		<script src="js/plugin/flot/jquery.flot.resize.min.js"></script>
		<script src="js/plugin/flot/jquery.flot.time.min.js"></script>
		<script src="js/plugin/flot/jquery.flot.tooltip.min.js"></script>
		<script src="js/plugin/vectormap/jquery-jvectormap-1.2.2.min.js"></script>
		<script src="js/plugin/vectormap/jquery-jvectormap-world-mill-en.js"></script>
		<script src="js/plugin/moment/moment.min.js"></script>
		<script src="js/plugin/fullcalendar/jquery.fullcalendar.min.js"></script>

		<script>
			$(document).ready(function() {
				pageSetUp();

			});

		</script>


	</body>

</html>