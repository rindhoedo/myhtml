<?php
    if (PHP_SAPI !== 'cli' && php_sapi_name() !== 'cli' && !defined('STDIN')) {
        if (!headers_sent()) {
            header('Content-Type: text/plain; charset=utf-8', true, 403);
        }
        echo "Forbidden: script, only alowd by command line (CLI).\n";
        exit(1);
    }
    define("EdoCMS",True);
    require_once "opt/mainconfig.php";

    $sql = "SELECT id,domain FROM `tbldomain` order by `id` asc ";
    $result = mysql_query($sql);
    $rows = mysql_num_rows($result);
    if ($rows){
        while($row = mysql_fetch_array($result)){
            $domain         = $row['domain'];
            $id             = $row['id'];
            //$resultCert     = getSSLCertExpiry($domain);
            $resultDomain   = getDomainExpiry(getBaseDomain($domain));
            echo "Domain: $domain \n";

            if(is_array($resultDomain)){
                $expireDomain = $resultDomain['expiry_date'];
                echo "Expire Date: {$resultDomain['expiry_date']}\n";
                $sqlInsert  = "UPDATE `tbldomain` SET `expire` = '$expireDomain' WHERE `id` = $id ;";
                echo "\n\n$sqlInsert\n\n";
                mysql_query($sqlInsert);
            }
        }
    }
?>